<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-12-25 03:43:26 --> Could not find the language line "012"
ERROR - 2014-12-25 03:43:26 --> Could not find the language line "030"
ERROR - 2014-12-25 03:43:26 --> Could not find the language line "add"
ERROR - 2014-12-25 11:58:59 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:05:53 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:07:01 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:07:59 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:08:41 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:41:58 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:43:07 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:44:02 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:44:27 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:45:10 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:45:33 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:45:59 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:47:45 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:48:47 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:49:17 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 12:59:22 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 13:00:47 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 13:02:01 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 13:12:05 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 14:38:29 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 14:39:24 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 14:40:13 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 14:49:13 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 14:54:09 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-25 07:12:09 --> Could not find the language line "340"
ERROR - 2014-12-25 07:12:09 --> Could not find the language line "add"
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/admin_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/admin_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/template_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/template_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-25 07:12:09 --> Could not find the language line "040"
