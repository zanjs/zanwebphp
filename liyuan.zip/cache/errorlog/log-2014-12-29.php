<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2014-12-29 10:32:17 --> Severity: Compile Error --> require(): Failed opening required 'G:\wwwroot\WWW\liyuan/team/config/module.php' (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\models\Module_model.php 922
ERROR - 2014-12-29 02:39:24 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:24 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:24 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/admin_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:24 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/admin_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:24 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:25 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/member_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:25 --> Severity: Warning --> include(G:\wwwroot\WWW\liyuan/omooo/system/language/english/template_lang.php): failed to open stream: No such file or directory G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:25 --> Severity: Warning --> include(): Failed opening 'G:\wwwroot\WWW\liyuan/omooo/system/language/english/template_lang.php' for inclusion (include_path='.;C:\php\pear') G:\wwwroot\WWW\liyuan\omooo\system\core\Lang.php 132
ERROR - 2014-12-29 02:39:25 --> Could not find the language line "040"
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:55 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:42:56 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:05 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:16 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:19 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:20 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:20 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:21 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:22 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:23 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:24 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:24 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:26 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:28 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:29 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:30 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:31 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:39 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:45 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:45 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:43:48 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:44:51 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:44:52 --> Severity: Parsing Error --> syntax error, unexpected ''                     => 1,' (T_ENCAPSED_AND_WHITESPACE) G:\wwwroot\WWW\liyuan\config\domain.php 19
ERROR - 2014-12-29 10:45:36 --> Query error: Table 'om_liyuan.om_1_team_form' doesn't exist - Invalid query: SELECT *
FROM `om_1_team_form`
WHERE `disabled` =0
ORDER BY `id` ASC
ERROR - 2014-12-29 11:12:28 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:13:22 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:14:21 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:15:28 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 03:19:46 --> Could not find the language line "030"
ERROR - 2014-12-29 03:19:46 --> Could not find the language line "add"
ERROR - 2014-12-29 03:19:46 --> Could not find the language line "190"
ERROR - 2014-12-29 03:19:46 --> Could not find the language line "206"
ERROR - 2014-12-29 03:19:46 --> Could not find the language line "325"
ERROR - 2014-12-29 03:19:46 --> Could not find the language line "112"
ERROR - 2014-12-29 11:41:09 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:44:13 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:45:15 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:46:08 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:46:43 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:46:58 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:47:36 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:48:02 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:48:37 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:49:32 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:51:01 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:51:34 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:52:01 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:53:07 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 11:53:48 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 12:02:31 --> Query error: Unknown column 'position' in 'field list' - Invalid query: SELECT `om_1_product`.`title`,`om_1_product`.`thumb`,position,profile FROM om_1_product WHERE 1 AND`om_1_product`.`id` IN (8,9,10,11,12,13,14,15) ORDER BY `om_1_product`.`displayorder` DESC,`om_1_product`.`updatetime` DESC LIMIT 8
ERROR - 2014-12-29 12:03:34 --> Query error: Unknown column 'position' in 'field list' - Invalid query: SELECT `om_1_product`.`title`,`om_1_product`.`thumb`,position,profile FROM om_1_product WHERE 1 AND`om_1_product`.`id` IN (8,9,10,11,12,13,14,15) ORDER BY `om_1_product`.`displayorder` DESC,`om_1_product`.`updatetime` DESC LIMIT 8
ERROR - 2014-12-29 04:06:18 --> Could not find the language line "190"
ERROR - 2014-12-29 04:06:18 --> Could not find the language line "206"
ERROR - 2014-12-29 04:06:18 --> Could not find the language line "325"
ERROR - 2014-12-29 04:06:18 --> Could not find the language line "112"
ERROR - 2014-12-29 12:47:27 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 12:49:55 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 12:51:50 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 12:53:42 --> 钩子调用文件（G:\wwwroot\WWW\liyuan/omooo/hooks/module_hooks.php）的不存在
ERROR - 2014-12-29 06:24:47 --> Could not find the language line "026"
ERROR - 2014-12-29 06:24:47 --> Could not find the language line "add"
ERROR - 2014-12-29 14:24:49 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 14:24:51 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 14:25:59 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 14:26:00 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 14:27:52 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 14:29:06 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 14:29:07 --> Severity: Parsing Error --> syntax error, unexpected end of file G:\wwwroot\WWW\liyuan\cache\templates\164195b9b65004e97db6edcb64b0b93d.cache.php 228
ERROR - 2014-12-29 07:26:10 --> Could not find the language line "026"
ERROR - 2014-12-29 07:26:10 --> Could not find the language line "add"
