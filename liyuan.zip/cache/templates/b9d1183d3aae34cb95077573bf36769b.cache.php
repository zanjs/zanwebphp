<?php if ($fn_include = $this->_include("header.html")) include($fn_include); ?>
</head>
<body>

<div class="animationload">
<div class="loader">Loading...</div>
</div>    
    <?php if ($fn_include = $this->_include("top.html")) include($fn_include);  if ($fn_include = $this->_include("nav.html")) include($fn_include); ?> 
 <!-- 科技与创新 -->
 <section class="post-wrapper-top jt-shadow clearfix">
        <div class="container">
            <div class="col-lg-12">
                <h2><?php $cache = $this->_cache_var('CATEGORY'); eval('echo $cache'.$this->_get_var('$catid.name').';');unset($cache); ?></h2>
                <ul class="breadcrumb pull-right">
                    <li><i class="fa fa-arrow-circle-left"></i>&nbsp;<a href="<?php echo SITE_URL; ?>">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                </ul>
            </div>
        </div>
    </section><!-- end post-wrapper-top -->
    
    <section class="white-wrapper">
        <div class="container">          
            <div id="boxed-portfolio" class="portfolio_wrapper padding-top">
                <?php $return = $this->list_tag("action=module catid=$catid field=title,url,description,thumb order=displayorder,updatetime page=1"); if ($return) extract($return); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 logo">
                    <div class="col-sm-5">
                    <div class="portfolio_item">
                        <div class="entry">
                            <img src="<?php echo dr_thumb($t['thumb']); ?>" alt="" class="img-responsive">
                            <div class="magnifier">
                                <div class="buttons">
                                    <a class="st btn btn-default" rel="bookmark" href="<?php echo $t['url']; ?>">查看更多</a>
                                    <h3><?php echo $t['title']; ?></h3>
                                </div><!-- end buttons -->
                            </div><!-- end magnifier -->
                        </div><!-- end entry -->
                    </div><!-- end portfolio_item -->
                    </div><!-- end col-sm-6 -->
                    <div class="col-sm-7">
                        <div class="title">
                            <h3><?php echo $t['title']; ?></h3>
                        </div><!-- end title -->    
                        <p><?php echo $t['description']; ?></p>                        
                       
                        <a href="<?php echo $t['url']; ?>" class="readmore">阅读更多..</a>
                    </div><!-- end col-sm-6 -->
                </div><!-- end col-lg-12 -->
    
                <?php } }  echo $error; ?>               
               
              
            </div>
            <div class="clearfix"></div>
                                            
                    <hr>
                                            
                    <div class="pagination_wrapper">
                        <!-- Pagination Normal -->
                        <ul class="pagination">
                            <?php echo $pages; ?>
                        </ul>
           </div><!-- end pagination_wrapper -->
            <!-- <div class="clearfix"></div>
                
            <div class="buttons padding-top text-center">
                <a href="portfolio-masonry.html" class="btn btn-primary btn-lg" title="">View All Projects</a>
            </div> -->
        
        </div><!-- end container -->
    </section><!-- end white-wrapper -->
 <!-- 科技与创新  end-->   
    
    <!-- footer -->
    <?php if ($fn_include = $this->_include("footer.html")) include($fn_include); ?>
    <!-- footer end-->
  <!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
  <script type="text/javascript" src="<?php echo HOME_THEME_PATH; ?>rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
  <script type="text/javascript" src="<?php echo HOME_THEME_PATH; ?>rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
  <script type="text/javascript">
    var revapi;
    jQuery(document).ready(function() {
        revapi = jQuery('.tp-banner').revolution(
        {
            delay:9000,
            startwidth:1170,
            startheight:500,
            hideThumbs:10,
            fullWidth:"on",
            forceFullWidth:"on"
        });
    }); //ready
  </script>



  <!-- Demo Switcher JS -->
  <script type="text/javascript" src="<?php echo HOME_THEME_PATH; ?>switcher/js/fswit.js"></script>
  <script src="<?php echo HOME_THEME_PATH; ?>switcher/js/bootstrap-select.js"></script>
  
</body>
</html>