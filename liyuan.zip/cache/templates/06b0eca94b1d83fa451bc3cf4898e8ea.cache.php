<div class="tp-banner-container">
            <div class="tp-banner" >
                <ul>
                 <?php $return = $this->list_tag("action=navigator type=1"); if ($return) extract($return); $count=count($return); if (is_array($return)) { foreach ($return as $key=>$t) { ?>
                   <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
					<img src="<?php echo dr_thumb($t['thumb']); ?>"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                        
                        <div class="tp-caption mini_title customin customout start"
							data-x="left" data-hoffset="330"
                            data-y="290"
                            data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="1000"
                            data-start="900"
                            data-easing="Back.easeInOut"
                            data-endspeed="300"><span><?php echo $t['description']; ?></span>
                        </div>
                       
                        <div class="tp-caption small_title  customin customout start"
							data-x="center" data-hoffset="0"
                            data-y="330"
                            data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="1600"
                            data-start="1100"
                            data-easing="Back.easeInOut"
                            data-endspeed="300">
                            <?php if ($t['url']=="#") {  } else { ?>
                            <a href="<?php echo $t['url']; ?>" <?php if ($t['target']) { ?>target="_blank"<?php } ?> class="btn btn-primary btn-lg">more</a>
                            <?php } ?>
                        </div>
                    </li>
                   <?php } } ?>        
                </ul>
                <div class="tp-bannertimer"></div>
            </div>
        </div>