<?php

/**
 * Omweb Website Management System
 * 
 * @since			version 2.0.3
 * @author			Omooo <kefu@omooo.com>
 * @license     	http://www.omooo.com/license
 * @copyright		Copyright (c) 2011 - 9999, Omooo.Com, Inc.
 */

/**
 * 站点域名文件
 */

return array(

	'liyuan.in'                     => 1,

);