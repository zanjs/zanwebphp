<?php

/**
 * 应用的钩子定义配置
 */

return array();