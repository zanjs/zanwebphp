<?php

return array(

	'DR_NAME'		=> '摩恩高级版',
	'DR_UPDATE'		=> '2014.8.20',
	'DR_VERSION'	=> '2.0.3',
	'DR_VERSION_ID'	=> 19

);