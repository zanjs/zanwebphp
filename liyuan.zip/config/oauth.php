<?php

/**
 * Omweb Website Management System
 * 
 * @since			version 2.0.3
 * @author			Omooo <kefu@omooo.com>
 * @license     	http://www.omooo.com/license
 * @copyright		Copyright (c) 2011 - 9999, Omooo.Com, Inc.
 */

/**
 * OAuth2授权登录
 */

return array (
    'sina' => 
    array (
        'key' => '3124513167',
        'use' => 0,
        'name' => '新浪微博',
        'icon' => 'sina',
        'secret' => 'ca0b65e3df315ba3e82374c496bbbaa0',
    ),
    'qq' => 
    array (
        'key' => '100265581',
        'use' => 0,
        'name' => 'QQ',
        'icon' => 'qq',
        'secret' => 'ec7116e7767bafc94308d48cfe1b1dd3',
    ),
    'baidu' => 
    array (
        'key' => 'L46bMQmcQ9P4lFcvY8NDvLqZ',
        'use' => 0,
        'name' => '百度',
        'icon' => 'baidu',
        'secret' => 'dt5CULF2p5lrkNYKn0nvsWbR8YaGaIz8',
    ),
    163 => 
    array (
        'key' => '8h5TYEpoycj8UUew',
        'use' => 0,
        'name' => '网易微博',
        'icon' => '163',
        'secret' => 'NgjhbEWM1qHcVu58N2Mh0E58dFBHzTsJ',
    ),
    360 => 
    array (
        'key' => '2070871330',
        'use' => 0,
        'name' => '360',
        'icon' => '360',
        'secret' => '0f6a1170ed3fd5a8c8dc595884281108',
    ),
    'google' => 
    array (
        'key' => '2070871330',
        'use' => 0,
        'name' => 'Google',
        'icon' => 'google',
        'secret' => '0f6a1170ed3fd5a8c8dc595884281108',
    ),
    'sohu' => 
    array (
        'key' => '2070871330',
        'use' => 0,
        'name' => '搜狐微博',
        'icon' => 'sohu',
        'secret' => '0f6a1170ed3fd5a8c8dc595884281108',
    ),
    'taobao' => 
    array (
        'key' => '2070871330',
        'use' => 0,
        'name' => '淘宝网',
        'icon' => 'taobao',
        'secret' => '0f6a1170ed3fd5a8c8dc595884281108',
    ),
);