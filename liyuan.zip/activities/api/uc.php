<?php

define('DISCUZ_ROOT', dirname(dirname(dirname(__FILE__))).'/member/ucenter/');

include DISCUZ_ROOT.'api/uc.php';