<?php

/**
 * Omweb Website Management System
 * 
 * @since			version 2.0.0
 * @author			Omooo <kefu@omooo.com>
 * @license     	http://www.omooo.com/license
 * @copyright		Copyright (c) 2011 - 9999, Omooo.Com, Inc.
 */

/**
 * 模块配置
 */

return array(

	'key'			=> 2,
	'name'			=> '社区活动',
	'author'		=> 'omWeb团队',
	'version'		=> '1.4',

);