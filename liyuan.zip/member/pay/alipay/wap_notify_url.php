<?php

define('DR_PAY_ID', 'alipay/wap');
define('DR_PAY_FILE', 'notify');
require dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'index.php';
