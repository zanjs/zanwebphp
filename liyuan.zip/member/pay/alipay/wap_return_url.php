<?php

define('DR_PAY_ID', 'alipay/wap');
define('DR_PAY_FILE', 'return');
require dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'index.php';
